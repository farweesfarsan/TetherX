const mongoose = require('mongoose');

const transactionSchema = mongoose.model({

    wallet :{
        type:mongoose.Schema.Types.ObjectId,
        ref:'Wallet',
        required:true
    },

    amount:{
        type:Number,
        required:true
    },

    transactionType:{
        type:String,
        enum:['Credit','Debit'],
        required:true
    },

    date:{
        type:Date,
        default:Date.now()
    },
     
    status:{
        type:String,
        required:true
    }
});

module.exports = mongoose.model('Transaction',transactionSchema);
